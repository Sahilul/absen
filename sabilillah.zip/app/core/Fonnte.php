<?php
/**
 * File: app/core/Fonnte.php
 * Helper class untuk integrasi dengan Fonnte WA Gateway
 */
class Fonnte
{
    private $apiUrl = 'https://api.fonnte.com/send';
    private $token;

    public function __construct($token = null)
    {
        if ($token) {
            $this->token = $token;
        } else {
            // Ambil dari pengaturan PSB
            $this->loadTokenFromSettings();
        }
    }

    /**
     * Load token dari database
     */
    private function loadTokenFromSettings()
    {
        require_once APPROOT . '/app/core/Database.php';
        $db = new Database();

        // Coba ambil dari psb_pengaturan dulu
        try {
            $db->query('SELECT wa_gateway_token FROM psb_pengaturan WHERE id = 1');
            $result = $db->single();
            if (!empty($result['wa_gateway_token'])) {
                $this->token = $result['wa_gateway_token'];
                return;
            }
        } catch (Exception $e) {
            // Table mungkin tidak ada, lanjut ke fallback
        }

        // Fallback ke pengaturan_aplikasi
        try {
            $db->query('SELECT wa_gateway_token FROM pengaturan_aplikasi WHERE id = 1');
            $result = $db->single();
            $this->token = $result['wa_gateway_token'] ?? '';
        } catch (Exception $e) {
            $this->token = '';
        }
    }

    /**
     * Kirim pesan WA
     * @param string $target Nomor WA (format: 628xxx)
     * @param string $message Pesan yang akan dikirim
     * @return array Response dari Fonnte
     */
    public function send($target, $message)
    {
        if (empty($this->token)) {
            return ['status' => false, 'reason' => 'Token WA Gateway tidak dikonfigurasi'];
        }

        // Format nomor (pastikan pakai 62)
        $target = $this->formatNumber($target);

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => [
                'target' => $target,
                'message' => $message,
                'countryCode' => '62'
            ],
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $this->token
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return ['status' => false, 'reason' => 'cURL Error: ' . $err];
        }

        return json_decode($response, true) ?: ['status' => false, 'reason' => 'Invalid response'];
    }

    /**
     * Format nomor HP ke format internasional
     */
    private function formatNumber($number)
    {
        // Hapus spasi dan karakter non-digit
        $number = preg_replace('/[^0-9]/', '', $number);

        // Ganti awalan 0 dengan 62
        if (substr($number, 0, 1) === '0') {
            $number = '62' . substr($number, 1);
        }

        // Tambah 62 jika belum ada
        if (substr($number, 0, 2) !== '62') {
            $number = '62' . $number;
        }

        return $number;
    }

    /**
     * Kirim pesan WA dengan file attachment (base64)
     * @param string $target Nomor WA (format: 628xxx)
     * @param string $message Pesan yang akan dikirim
     * @param string $fileContent Binary file content (will be base64 encoded)
     * @param string $filename Nama file
     * @return array Response dari Fonnte
     */
    public function sendWithFile($target, $message, $fileContent, $filename = 'document.pdf')
    {
        if (empty($this->token)) {
            return ['status' => false, 'reason' => 'Token WA Gateway tidak dikonfigurasi'];
        }

        $target = $this->formatNumber($target);

        // Encode file to base64
        $fileBase64 = base64_encode($fileContent);

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => [
                'target' => $target,
                'message' => $message,
                'file' => $fileBase64,
                'filename' => $filename,
                'countryCode' => '62'
            ],
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $this->token
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return ['status' => false, 'reason' => 'cURL Error: ' . $err];
        }

        return json_decode($response, true) ?: ['status' => false, 'reason' => 'Invalid response'];
    }

    /**
     * Kirim notifikasi pendaftaran berhasil
     */
    public function sendPendaftaranBerhasil($noWa, $nama, $noPendaftaran)
    {
        $message = "✅ *Pendaftaran PSB Berhasil*\n\n";
        $message .= "Halo *{$nama}*,\n\n";
        $message .= "Pendaftaran Anda telah berhasil tercatat dengan nomor:\n";
        $message .= "*{$noPendaftaran}*\n\n";
        $message .= "Silakan lengkapi formulir dan upload dokumen di dashboard pendaftaran.\n\n";
        $message .= "Terima kasih.";

        return $this->send($noWa, $message);
    }

    /**
     * Kirim notifikasi revisi dokumen
     */
    public function sendRevisiDokumen($noWa, $nama, $catatan)
    {
        $message = "⚠️ *Revisi Dokumen Diperlukan*\n\n";
        $message .= "Halo *{$nama}*,\n\n";
        $message .= "Dokumen pendaftaran Anda memerlukan revisi:\n";
        $message .= "_{$catatan}_\n\n";
        $message .= "Silakan login dan perbaiki dokumen Anda.\n\n";
        $message .= "Terima kasih.";

        return $this->send($noWa, $message);
    }

    /**
     * Kirim notifikasi diterima
     */
    public function sendDiterima($noWa, $nama, $lembaga)
    {
        $message = "🎉 *SELAMAT! Anda DITERIMA*\n\n";
        $message .= "Halo *{$nama}*,\n\n";
        $message .= "Dengan gembira kami sampaikan bahwa Anda *DITERIMA* di:\n";
        $message .= "*{$lembaga}*\n\n";
        $message .= "Silakan segera melakukan daftar ulang.\n\n";
        $message .= "Selamat bergabung! 🙏";

        return $this->send($noWa, $message);
    }

    /**
     * Kirim notifikasi ditolak
     */
    public function sendDitolak($noWa, $nama, $alasan = '')
    {
        $message = "📋 *Informasi Pendaftaran PSB*\n\n";
        $message .= "Halo *{$nama}*,\n\n";
        $message .= "Mohon maaf, pendaftaran Anda belum dapat kami terima saat ini.";
        if (!empty($alasan)) {
            $message .= "\n\nKeterangan: _{$alasan}_";
        }
        $message .= "\n\nTerima kasih atas partisipasi Anda.";

        return $this->send($noWa, $message);
    }

    /**
     * Kirim token reset password
     */
    public function sendResetToken($noWa, $nama, $token)
    {
        $message = "🔐 *Reset Password PSB*\n\n";
        $message .= "Halo *{$nama}*,\n\n";
        $message .= "Kode reset password Anda:\n";
        $message .= "*{$token}*\n\n";
        $message .= "Kode berlaku 15 menit.\n";
        $message .= "Jika Anda tidak meminta reset password, abaikan pesan ini.";

        return $this->send($noWa, $message);
    }
}

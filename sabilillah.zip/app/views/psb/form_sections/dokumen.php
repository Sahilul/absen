<?php
// Form Section: Dokumen
$p = $pendaftar;
$docs = $dokumen ?? [];

$requiredDocs = [
    'kartu_keluarga' => ['label' => 'Kartu Keluarga (KK)', 'icon' => 'file-text'],
    'akta_kelahiran' => ['label' => 'Akta Kelahiran', 'icon' => 'file-text'],
    'ktp_ayah' => ['label' => 'KTP Ayah', 'icon' => 'id-card'],
    'ktp_ibu' => ['label' => 'KTP Ibu', 'icon' => 'id-card'],
    'ijazah' => ['label' => 'Ijazah/SKL', 'icon' => 'award'],
    'kip' => ['label' => 'Kartu Indonesia Pintar (KIP)', 'icon' => 'credit-card'],
    'kis_kks' => ['label' => 'KIS/KKS', 'icon' => 'heart'],
    'pkh' => ['label' => 'PKH', 'icon' => 'wallet'],
];

$uploadedDocs = [];
foreach ($docs as $doc) {
    $uploadedDocs[$doc['jenis_dokumen']] = $doc;
}
?>

<div class="space-y-4">
    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
        <p class="text-sm text-blue-700">
            <i data-lucide="info" class="w-4 h-4 inline"></i>
            <strong>Auto-save:</strong> Dokumen akan otomatis tersimpan setelah dipilih. Format: JPG, PNG, PDF. Maksimal
            2MB per file.
        </p>
    </div>

    <div class="grid sm:grid-cols-2 gap-4">
        <?php foreach ($requiredDocs as $key => $docInfo): ?>
            <?php $uploaded = $uploadedDocs[$key] ?? null; ?>
            <div class="border border-gray-200 rounded-xl p-4 hover:border-orange-300 transition-colors"
                id="doc_container_<?= $key; ?>">
                <div class="flex items-start gap-3">
                    <?php if ($uploaded): ?>
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center shrink-0">
                            <i data-lucide="check-circle" class="w-6 h-6 text-green-600"></i>
                        </div>
                    <?php else: ?>
                        <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center shrink-0">
                            <i data-lucide="<?= $docInfo['icon']; ?>" class="w-6 h-6 text-gray-400"></i>
                        </div>
                    <?php endif; ?>

                    <div class="flex-1 min-w-0">
                        <h4 class="font-semibold text-gray-800 text-sm"><?= $docInfo['label']; ?></h4>
                        <?php if ($uploaded): ?>
                            <p class="text-xs text-green-600 mt-1">✓ Sudah diupload</p>
                            <?php
                            // Use serveFile endpoint which doesn't require login
                            $fileUrl = BASEURL . '/psb/serveFile/' . $p['id_pendaftar'] . '/' . $key;
                            $isPdf = strtolower(pathinfo($uploaded['path_file'], PATHINFO_EXTENSION)) === 'pdf';
                            ?>
                            <div class="mt-2 flex flex-wrap gap-2">
                                <button type="button"
                                    onclick="previewDoc('<?= $fileUrl; ?>', '<?= $docInfo['label']; ?>', <?= $isPdf ? 'true' : 'false'; ?>)"
                                    class="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1">
                                    <i data-lucide="eye" class="w-3 h-3"></i> Lihat
                                </button>
                                <a href="<?= $fileUrl; ?>" target="_blank"
                                    class="text-xs text-gray-600 hover:text-gray-800 flex items-center gap-1">
                                    <i data-lucide="download" class="w-3 h-3"></i> Download
                                </a>
                            </div>
                        <?php else: ?>
                            <p class="text-xs text-gray-500 mt-1">Belum diupload</p>
                        <?php endif; ?>

                        <div class="mt-3">
                            <input type="file" name="dokumen[<?= $key; ?>]" id="doc_<?= $key; ?>"
                                accept=".jpg,.jpeg,.png,.pdf" class="hidden"
                                onchange="uploadDokumen(this, '<?= $key; ?>', '<?= $p['id_pendaftar']; ?>')">
                            <label for="doc_<?= $key; ?>"
                                class="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 border border-orange-200 rounded-lg text-xs text-orange-700 hover:bg-orange-100 transition-colors">
                                <i data-lucide="upload" class="w-3 h-3"></i>
                                <?= $uploaded ? 'Ganti File' : 'Upload File'; ?>
                            </label>
                            <span class="text-xs text-gray-400 ml-2" id="status_<?= $key; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Preview Modal -->
<div id="previewModal" class="fixed inset-0 bg-black/70 z-50 hidden items-center justify-center p-4"
    onclick="closePreview(event)">
    <div class="bg-white rounded-xl max-w-4xl max-h-[90vh] w-full overflow-hidden" onclick="event.stopPropagation()">
        <div class="flex items-center justify-between p-4 border-b">
            <h3 class="font-bold text-gray-800" id="previewTitle">Preview</h3>
            <button type="button" onclick="closePreview(); return false;" class="p-2 hover:bg-gray-100 rounded-lg">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>
        <div class="p-4 overflow-auto max-h-[calc(90vh-80px)]" id="previewContent"></div>
    </div>
</div>

<script>
    // Auto-upload dokumen
    async function uploadDokumen(input, jenis, idPendaftar) {
        const file = input.files[0];
        const statusEl = document.getElementById('status_' + jenis);
        const container = document.getElementById('doc_container_' + jenis);

        if (!file) return;

        // Validate file size (2MB max)
        if (file.size > 2 * 1024 * 1024) {
            statusEl.textContent = '❌ File terlalu besar (max 2MB)';
            statusEl.className = 'text-xs text-red-500 ml-2';
            return;
        }

        // Validate file type
        const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        if (!validTypes.includes(file.type)) {
            statusEl.textContent = '❌ Format tidak didukung';
            statusEl.className = 'text-xs text-red-500 ml-2';
            return;
        }

        statusEl.textContent = '⏳ Mengupload...';
        statusEl.className = 'text-xs text-blue-500 ml-2';

        const formData = new FormData();
        formData.append('dokumen[' + jenis + ']', file);
        formData.append('section', 'dokumen');
        formData.append('jenis', jenis);

        try {
            const response = await fetch('<?= BASEURL; ?>/psb/uploadDokumen/' + idPendaftar, {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                statusEl.textContent = '✓ Tersimpan!';
                statusEl.className = 'text-xs text-green-500 ml-2';

                // Reload after short delay to show updated preview
                setTimeout(() => location.reload(), 800);
            } else {
                statusEl.textContent = '❌ ' + (result.message || 'Gagal upload');
                statusEl.className = 'text-xs text-red-500 ml-2';
            }
        } catch (error) {
            statusEl.textContent = '❌ Error: ' + error.message;
            statusEl.className = 'text-xs text-red-500 ml-2';
        }
    }

    // Preview dokumen
    function previewDoc(url, title, isPdf = false) {
        const modal = document.getElementById('previewModal');
        const content = document.getElementById('previewContent');
        const titleEl = document.getElementById('previewTitle');

        titleEl.textContent = title;

        // Check if PDF
        if (isPdf) {
            content.innerHTML = '<iframe src="' + url + '" class="w-full h-[70vh]" frameborder="0"></iframe>';
        } else {
            content.innerHTML = '<img src="' + url + '" class="max-w-full h-auto mx-auto rounded-lg" alt="' + title + '">';
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closePreview(e) {
        if (e && e.target !== document.getElementById('previewModal')) return;
        const modal = document.getElementById('previewModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
</script>
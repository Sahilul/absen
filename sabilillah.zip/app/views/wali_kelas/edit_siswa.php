<main class="flex-1 overflow-x-hidden overflow-y-auto bg-secondary-50 p-4 md:p-6">
    <!-- Header -->
    <div class="mb-4">
        <div class="bg-white shadow-sm rounded-xl p-4 md:p-5">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div>
                    <h4 class="text-lg md:text-xl font-bold text-slate-800 mb-1"><?= $data['judul'] ?></h4>
                    <p class="text-slate-500 text-sm">
                        <span class="font-semibold text-slate-700"><?= htmlspecialchars($data['wali_kelas_info']['nama_kelas'] ?? '-') ?></span>
                        <span class="mx-2">•</span>
                        <span class="font-semibold text-slate-700"><?= htmlspecialchars($data['session_info']['nama_semester'] ?? '') ?></span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php Flasher::flash(); ?>

    <!-- Form Edit Siswa -->
    <div class="bg-white shadow-sm rounded-xl p-4 md:p-6">
        <form action="<?= BASEURL ?>/waliKelas/updateSiswa" method="POST">
            <input type="hidden" name="id_siswa" value="<?= $data['siswa']['id_siswa'] ?>">
            
            <!-- Section: Data Identitas -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-800 mb-4 pb-2 border-b-2 border-sky-200 flex items-center gap-2">
                    <i data-lucide="user-circle" class="w-5 h-5 text-sky-600"></i>
                    Data Identitas
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
                    <!-- NISN -->
                    <div>
                        <label for="nisn" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="hash" class="w-4 h-4 inline-block mr-1"></i>
                            NISN <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="nisn" 
                            name="nisn" 
                            value="<?= htmlspecialchars($data['siswa']['nisn'] ?? '') ?>"
                            required
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Contoh: 0012345678"
                        >
                        <p class="text-xs text-slate-500 mt-1">Username untuk login</p>
                    </div>

                    <!-- Nama Siswa -->
                    <div>
                        <label for="nama_siswa" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="user" class="w-4 h-4 inline-block mr-1"></i>
                            Nama Lengkap <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="nama_siswa" 
                            name="nama_siswa" 
                            value="<?= htmlspecialchars($data['siswa']['nama_siswa'] ?? '') ?>"
                            required
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Contoh: Ahmad Fauzi"
                        >
                    </div>

                    <!-- Jenis Kelamin -->
                    <div>
                        <label for="jenis_kelamin" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="users" class="w-4 h-4 inline-block mr-1"></i>
                            Jenis Kelamin <span class="text-red-500">*</span>
                        </label>
                        <select 
                            id="jenis_kelamin" 
                            name="jenis_kelamin" 
                            required
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                        >
                            <option value="">-- Pilih --</option>
                            <option value="L" <?= ($data['siswa']['jenis_kelamin'] ?? '') == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                            <option value="P" <?= ($data['siswa']['jenis_kelamin'] ?? '') == 'P' ? 'selected' : '' ?>>Perempuan</option>
                        </select>
                    </div>

                    <!-- Tempat Lahir -->
                    <div>
                        <label for="tempat_lahir" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="map-pin" class="w-4 h-4 inline-block mr-1"></i>
                            Tempat Lahir
                        </label>
                        <input 
                            type="text" 
                            id="tempat_lahir" 
                            name="tempat_lahir" 
                            value="<?= htmlspecialchars($data['siswa']['tempat_lahir'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Contoh: Jakarta"
                        >
                    </div>

                    <!-- Tanggal Lahir -->
                    <div>
                        <label for="tanggal_lahir" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="calendar" class="w-4 h-4 inline-block mr-1"></i>
                            Tanggal Lahir
                        </label>
                        <input 
                            type="date" 
                            id="tanggal_lahir" 
                            name="tanggal_lahir" 
                            value="<?= htmlspecialchars($data['siswa']['tgl_lahir'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                        >
                    </div>
                </div>
            </div>

            <!-- Section: Kontak -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-800 mb-4 pb-2 border-b-2 border-sky-200 flex items-center gap-2">
                    <i data-lucide="phone" class="w-5 h-5 text-sky-600"></i>
                    Informasi Kontak
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
                    <!-- No WhatsApp -->
                    <div>
                        <label for="no_wa" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="smartphone" class="w-4 h-4 inline-block mr-1"></i>
                            No. WhatsApp
                        </label>
                        <input 
                            type="text" 
                            id="no_wa" 
                            name="no_wa" 
                            value="<?= htmlspecialchars($data['siswa']['no_wa'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Contoh: 081234567890"
                        >
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="email" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="mail" class="w-4 h-4 inline-block mr-1"></i>
                            Email
                        </label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            value="<?= htmlspecialchars($data['siswa']['email'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Contoh: siswa@email.com"
                        >
                    </div>

                    <!-- Alamat -->
                    <div class="md:col-span-2">
                        <label for="alamat" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="home" class="w-4 h-4 inline-block mr-1"></i>
                            Alamat Lengkap
                        </label>
                        <textarea 
                            id="alamat" 
                            name="alamat" 
                            rows="3"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Masukkan alamat lengkap siswa"
                        ><?= htmlspecialchars($data['siswa']['alamat'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <!-- Section: Data Orang Tua -->
            <div class="mb-6">
                <h3 class="text-lg font-bold text-slate-800 mb-4 pb-2 border-b-2 border-sky-200 flex items-center gap-2">
                    <i data-lucide="users" class="w-5 h-5 text-sky-600"></i>
                    Data Orang Tua
                </h3>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
                    <!-- Nama Ayah Kandung -->
                    <div>
                        <label for="ayah_kandung" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="user" class="w-4 h-4 inline-block mr-1"></i>
                            Nama Ayah Kandung
                        </label>
                        <input 
                            type="text" 
                            id="ayah_kandung" 
                            name="ayah_kandung" 
                            value="<?= htmlspecialchars($data['siswa']['ayah_kandung'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Nama lengkap ayah kandung"
                        >
                    </div>

                    <!-- Nama Ibu Kandung -->
                    <div>
                        <label for="ibu_kandung" class="block text-sm font-semibold text-slate-700 mb-2">
                            <i data-lucide="user" class="w-4 h-4 inline-block mr-1"></i>
                            Nama Ibu Kandung
                        </label>
                        <input 
                            type="text" 
                            id="ibu_kandung" 
                            name="ibu_kandung" 
                            value="<?= htmlspecialchars($data['siswa']['ibu_kandung'] ?? '') ?>"
                            class="w-full border border-slate-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3 text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-400 transition-all"
                            placeholder="Nama lengkap ibu kandung"
                        >
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="mt-6 flex flex-col sm:flex-row gap-3">
                <button 
                    type="submit" 
                    class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
                >
                    <i data-lucide="save" class="w-4 h-4"></i>
                    Simpan Perubahan
                </button>
                <a 
                    href="<?= BASEURL ?>/waliKelas/daftarSiswa" 
                    class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-lg transition-colors"
                >
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                    Kembali
                </a>
            </div>
        </form>
    </div>

    <!-- Info Box -->
    <div class="mt-5 bg-sky-50 border border-sky-200 rounded-xl p-4">
        <div class="flex gap-3">
            <div class="shrink-0">
                <i data-lucide="info" class="w-5 h-5 text-sky-600"></i>
            </div>
            <div class="flex-1">
                <h6 class="font-semibold text-sky-900 text-sm mb-1">Informasi</h6>
                <ul class="text-xs text-sky-700 space-y-1 list-disc list-inside">
                    <li>Field dengan tanda <span class="text-red-500">*</span> wajib diisi</li>
                    <li>NISN digunakan sebagai username login siswa</li>
                    <li>Pastikan data yang diinput sudah benar sebelum menyimpan</li>
                </ul>
            </div>
        </div>
    </div>
</main>

<script>
// Initialize Lucide icons
if (typeof lucide !== 'undefined') {
    lucide.createIcons();
}
</script>

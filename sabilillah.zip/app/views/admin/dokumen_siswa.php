<?php
$siswa = $data['siswa'] ?? [];
$dokumen = $data['dokumen'] ?? [];

$jenisDokumen = [
    'akta_kelahiran' => 'Akta Kelahiran',
    'kk' => 'Kartu Keluarga',
    'ktp_ortu' => 'KTP Orang Tua',
    'foto' => 'Pas Foto',
    'ijazah' => 'Ijazah',
    'skhun' => 'SKHUN',
    'rapor' => 'Rapor',
    'surat_pindah' => 'Surat Pindah',
    'kip' => 'Kartu Indonesia Pintar',
    'sktm' => 'SKTM',
    'lainnya' => 'Dokumen Lainnya'
];
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dokumen Siswa - <?= htmlspecialchars($siswa['nama_siswa'] ?? ''); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-50">
    <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6">
        <!-- Page Header -->
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <div class="flex items-center">
                <a href="<?= BASEURL; ?>/admin/siswa"
                    class="text-gray-500 hover:text-indigo-600 mr-4 p-2 rounded-lg hover:bg-gray-100">
                    <i data-lucide="arrow-left" class="w-5 h-5"></i>
                </a>
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">Dokumen Siswa</h2>
                    <p class="text-gray-600 mt-1"><?= htmlspecialchars($siswa['nama_siswa'] ?? ''); ?> (NISN:
                        <?= $siswa['nisn'] ?? '-'; ?>)
                    </p>
                </div>
            </div>
        </div>

        <?php if (class_exists('Flasher')) {
            Flasher::flash();
        } ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Upload Form -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-xl shadow-sm border p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <i data-lucide="upload" class="w-5 h-5 text-amber-600"></i> Upload Dokumen
                    </h3>
                    <form action="<?= BASEURL; ?>/admin/uploadDokumenSiswa" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id_siswa" value="<?= $siswa['id_siswa']; ?>">

                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Dokumen</label>
                                <select name="jenis_dokumen" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 bg-white">
                                    <option value="">-- Pilih Jenis --</option>
                                    <?php foreach ($jenisDokumen as $key => $label): ?>
                                        <option value="<?= $key; ?>"><?= $label; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">File Dokumen</label>
                                <input type="file" name="file_dokumen" required accept=".pdf,.jpg,.jpeg,.png"
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-amber-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100">
                                <p class="text-xs text-gray-500 mt-1">Format: PDF, JPG, PNG (max 2MB)</p>
                            </div>
                            <button type="submit"
                                class="w-full bg-amber-500 hover:bg-amber-600 text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center gap-2">
                                <i data-lucide="upload" class="w-4 h-4"></i> Upload
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Document List -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                    <div class="px-6 py-4 border-b bg-gray-50 flex items-center justify-between">
                        <h3 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                            <i data-lucide="folder-open" class="w-5 h-5 text-amber-600"></i> Daftar Dokumen
                        </h3>
                        <span class="text-sm text-gray-500"><?= count($dokumen); ?> dokumen</span>
                    </div>

                    <?php if (!empty($dokumen)): ?>
                        <div class="divide-y">
                            <?php foreach ($dokumen as $doc): ?>
                                <div class="px-6 py-4 flex items-center justify-between hover:bg-gray-50">
                                    <div class="flex items-center gap-4">
                                        <div class="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                                            <i data-lucide="file-text" class="w-5 h-5 text-amber-600"></i>
                                        </div>
                                        <div>
                                            <p class="font-medium text-gray-900">
                                                <?= htmlspecialchars($jenisDokumen[$doc['jenis_dokumen']] ?? $doc['jenis_dokumen']); ?>
                                            </p>
                                            <p class="text-xs text-gray-500">
                                                <?= htmlspecialchars($doc['nama_file']); ?>
                                                (<?= number_format($doc['ukuran'] / 1024, 1); ?> KB)
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <a href="<?= BASEURL; ?>/admin/lihatDokumenSiswa/<?= $doc['id_dokumen']; ?>"
                                            target="_blank" class="p-2 bg-blue-100 hover:bg-blue-200 text-blue-600 rounded-lg"
                                            title="Lihat">
                                            <i data-lucide="eye" class="w-4 h-4"></i>
                                        </a>
                                        <a href="<?= BASEURL; ?>/admin/downloadDokumenSiswa/<?= $doc['id_dokumen']; ?>"
                                            class="p-2 bg-green-100 hover:bg-green-200 text-green-600 rounded-lg"
                                            title="Download">
                                            <i data-lucide="download" class="w-4 h-4"></i>
                                        </a>
                                        <button
                                            onclick="confirmDelete(<?= $doc['id_dokumen']; ?>, '<?= htmlspecialchars($jenisDokumen[$doc['jenis_dokumen']] ?? $doc['jenis_dokumen']); ?>')"
                                            class="p-2 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg" title="Hapus">
                                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="px-6 py-12 text-center">
                            <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <i data-lucide="folder-x" class="w-8 h-8 text-gray-400"></i>
                            </div>
                            <p class="text-gray-500">Belum ada dokumen yang diupload</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal"
        class="hidden fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-lg w-full max-w-md border border-gray-200">
            <div class="px-6 py-4 border-b flex items-center">
                <i data-lucide="alert-triangle" class="w-5 h-5 text-red-500 mr-2"></i>
                <h4 class="text-lg font-semibold text-gray-800">Hapus Dokumen?</h4>
            </div>
            <div class="px-6 py-5">
                <p class="text-sm text-gray-600">
                    Anda yakin ingin menghapus dokumen <strong id="deleteDocName"></strong>?
                </p>
            </div>
            <div class="px-6 py-4 bg-gray-50 border-t flex justify-end space-x-3">
                <button onclick="closeDeleteModal()"
                    class="px-4 py-2 text-sm font-medium rounded-md bg-gray-100 hover:bg-gray-200 text-gray-700">Batal</button>
                <button id="confirmDeleteBtn"
                    class="px-4 py-2 text-sm font-medium rounded-md bg-red-600 hover:bg-red-700 text-white flex items-center">
                    <i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Hapus
                </button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            lucide.createIcons();
        });

        let deleteId = null;
        function confirmDelete(id, name) {
            deleteId = id;
            document.getElementById('deleteDocName').textContent = name;
            document.getElementById('deleteModal').classList.remove('hidden');
        }
        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.add('hidden');
        }
        document.getElementById('confirmDeleteBtn').addEventListener('click', function () {
            if (deleteId) {
                window.location.href = '<?= BASEURL; ?>/admin/hapusDokumenSiswa/' + deleteId + '/<?= $siswa['id_siswa']; ?>';
            }
        });
    </script>
</body>

</html>
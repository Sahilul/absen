-- Migration: QR Validation Tables
-- Jalankan sekali di database `absen`.

CREATE TABLE IF NOT EXISTS `qr_validation_tokens` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `doc_type` VARCHAR(50) NOT NULL,
  `doc_id` VARCHAR(100) NOT NULL,
  `identifier` VARCHAR(100) NOT NULL,
  `token` CHAR(64) NOT NULL,
  `issued_at` DATETIME NOT NULL,
  `expires_at` DATETIME NULL,
  `meta_json` JSON NULL,
  `revoked` TINYINT(1) NOT NULL DEFAULT 0,
  UNIQUE KEY `u_token` (`token`),
  KEY `k_doc` (`doc_type`,`doc_id`),
  KEY `k_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `qr_validation_logs` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `token` CHAR(64) NOT NULL,
  `scanned_at` DATETIME NOT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `is_valid` TINYINT(1) NOT NULL,
  `notes` VARCHAR(255) NULL,
  KEY `k_token` (`token`),
  KEY `k_scanned` (`scanned_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
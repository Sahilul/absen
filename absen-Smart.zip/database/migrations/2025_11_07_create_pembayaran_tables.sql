-- Pembayaran feature schema (Option B)
-- Run this SQL in your MySQL database.

-- 1) Categories (global, optional)
CREATE TABLE IF NOT EXISTS pembayaran_kategori (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  deskripsi VARCHAR(255) DEFAULT NULL,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) Tagihan (global or class-scoped)
CREATE TABLE IF NOT EXISTS pembayaran_tagihan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(150) NOT NULL,
  kategori_id INT NULL,
  is_global TINYINT(1) NOT NULL DEFAULT 0,
  ref_global_id INT NULL, -- if derived from a global tagihan
  id_tp INT NOT NULL,
  id_semester INT NULL,
  id_kelas INT NULL, -- NULL for global; set for class-scoped by wali
  tipe ENUM('sekali','bulanan') NOT NULL DEFAULT 'sekali',
  nominal_default BIGINT NOT NULL DEFAULT 0,
  jatuh_tempo DATE NULL,
  created_by_user INT NULL,
  created_by_role ENUM('admin','wali_kelas','guru') DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_tag_kat FOREIGN KEY (kategori_id) REFERENCES pembayaran_kategori(id) ON DELETE SET NULL,
  CONSTRAINT fk_tag_ref_global FOREIGN KEY (ref_global_id) REFERENCES pembayaran_tagihan(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3) Mapping per siswa (amount overrides/discounts and status)
CREATE TABLE IF NOT EXISTS pembayaran_tagihan_siswa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tagihan_id INT NOT NULL,
  id_siswa INT NOT NULL,
  nominal BIGINT NOT NULL DEFAULT 0,
  diskon BIGINT NOT NULL DEFAULT 0,
  total_terbayar BIGINT NOT NULL DEFAULT 0,
  status ENUM('belum','sebagian','lunas') NOT NULL DEFAULT 'belum',
  jatuh_tempo DATE NULL,
  periode_bulan TINYINT NOT NULL DEFAULT 0, -- 0 = non-bulanan; 1..12 untuk bulanan
  periode_tahun INT NOT NULL DEFAULT 0,
  keterangan VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_tagihan_siswa_periode (tagihan_id, id_siswa, periode_bulan, periode_tahun),
  CONSTRAINT fk_tgs_tagihan FOREIGN KEY (tagihan_id) REFERENCES pembayaran_tagihan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4) Transaksi (payments)
CREATE TABLE IF NOT EXISTS pembayaran_transaksi (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tagihan_id INT NOT NULL,
  id_siswa INT NOT NULL,
  tanggal DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  jumlah BIGINT NOT NULL,
  metode VARCHAR(50) NULL, -- tunai, transfer, dll.
  keterangan VARCHAR(255) NULL,
  bukti_path VARCHAR(255) NULL,
  user_input_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_trx_tagihan FOREIGN KEY (tagihan_id) REFERENCES pembayaran_tagihan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Helpful views or indexes
CREATE INDEX idx_tagihan_kelas ON pembayaran_tagihan (id_tp, id_semester, id_kelas);
CREATE INDEX idx_tagihan_ref ON pembayaran_tagihan (ref_global_id);
CREATE INDEX idx_tgs_siswa ON pembayaran_tagihan_siswa (id_siswa);
CREATE INDEX idx_trx_siswa ON pembayaran_transaksi (id_siswa, tagihan_id);
